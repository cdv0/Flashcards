
  # Flashcard App Design

  This is a code bundle for Flashcard App Design. The original project is available at https://www.figma.com/design/csCDJILBftCKjf9FRW2Myk/Flashcard-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  